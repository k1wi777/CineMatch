﻿**CineMatch: Plataforma de recomendación y reseñas de películas y series Especificación de Requisitos de Software** 

![](Aspose.Words.69a4485e-d3ec-40ea-8322-cb0ba1e26bc0.001.png)

**Autores**  

**Camilo David Pacheco Prieto** 

**José Alfredo Padilla Ortiz** 

Facultad de Ingeniería Departamento de Ingeniería de Sistemas 

Desarrollo Web II 

**Docente** 

`                                                                                   `**Pierre Peña Salgado, MSc**   Facultad de Ingeniería  

Departamento de Ingeniería de Sistemas  

**Universidad de Córdoba** 

**Montería, Córdoba**  

**2026.** 

**Tabla de contenido** 

[Introducción ](#_page2_x82.00_y70.92).....................................................................................................................[.3 ](#_page2_x82.00_y70.92)

1. [Planteamiento del problema .](#_page3_x82.00_y70.92).......................................................................................[.4 ](#_page3_x82.00_y70.92)
1. [Justificación .](#_page4_x82.00_y70.92)...........................................................................................................[.5 ](#_page4_x82.00_y70.92)
1. [Objetivo general ](#_page5_x82.00_y70.92)....................................................................................................[.6 ](#_page5_x82.00_y70.92)
1. [Objetivos específicos ](#_page5_x82.00_y190.92).............................................................................................[.6 ](#_page5_x82.00_y190.92)
2. [Especificación de Requisitos de Software ](#_page6_x82.00_y70.92)....................................................................[.7 ](#_page6_x82.00_y70.92)
1. [Descripción del sistema ](#_page6_x82.00_y112.92).........................................................................................[.7 ](#_page6_x82.00_y112.92)
1. [Objetivo del sistema ](#_page7_x82.00_y70.92)..............................................................................................[.8 ](#_page7_x82.00_y70.92)
1. [Análisis de usuarios .](#_page7_x82.00_y217.92)...............................................................................................[.8 ](#_page7_x82.00_y217.92)

[2.3.1 Descripción de roles .](#_page7_x82.00_y437.92)......................................................................................[.8 ](#_page7_x82.00_y437.92)

4. [Requisitos funcionales ](#_page8_x82.00_y70.92)...........................................................................................[.9 ](#_page8_x82.00_y70.92)
1. [Requisitos no funcionales ](#_page10_x82.00_y273.92)............................................................................[.11 ](#_page10_x82.00_y273.92)
1. [Reglas de negocio.](#_page12_x82.00_y70.92)........................................................................................[.13 ](#_page12_x82.00_y70.92)
1. [Alcance por fases ](#_page14_x82.00_y387.92).........................................................................................[.15 ](#_page14_x82.00_y387.92)
5. [Diagrama de caso de uso .](#_page15_x82.00_y70.92)....................................................................................[.16 ](#_page15_x82.00_y70.92)
6. [Documentación de casos de uso ](#_page17_x82.00_y70.92).........................................................................[.18 ](#_page17_x82.00_y70.92)
6. [Modelo entidad-relación ](#_page27_x82.00_y70.92).....................................................................................[.28 ](#_page27_x82.00_y70.92)
6. [Diagrama de secuencia .](#_page29_x82.00_y70.92).......................................................................................[.30 ](#_page29_x82.00_y70.92)
6. [Diccionario de datos ](#_page35_x82.00_y70.92)............................................................................................[.36 ](#_page35_x82.00_y70.92)

<a name="_page2_x82.00_y70.92"></a>**Introducción**

CineMatch es una plataforma web de recomendación y reseñas de películas y series cuyo propósito es facilitar la búsqueda, selección y descubrimiento de contenido audiovisual mediante  la  interacción  entre  usuarios.  A  diferencia  de  los  sistemas  que  se  centran principalmente en la consulta de catálogos y calificaciones generales, la plataforma busca integrar las opiniones personales con las relaciones sociales de sus usuarios, permitiendo compartir recomendaciones de títulos acompañadas de un motivo y, de forma opcional, de la reseña de quien recomienda. Además, cada usuario registra sus categorías de interés, de modo que un amigo pueda saber si un título encaja con sus gustos antes de recomendárselo. De esta manera, se pretende ofrecer información que ayude a determinar si un título puede resultar de interés antes de consultar todos sus detalles. 

El sistema contempla funcionalidades de gestión de usuarios (registro con username único y selección de intereses, administración de perfiles y relaciones de amistad), consulta y búsqueda de películas y series, publicación de reseñas con calificación de 1 a 5 y visibilidad pública o solo para amigos, y envío y recepción de recomendaciones con un ciclo de estados definido  (enviada,  abierta,  aceptada,  descartada  y  completada).  Asimismo,  incorpora etiquetas que resumen cada reseña, recomendaciones generales elaboradas a partir de las calificaciones y reseñas públicas de la comunidad, notificaciones y una biblioteca personal donde se organiza el estado de cada título (pendiente, viendo, vista o abandonada). Estas funcionalidades se complementan con la integración de una fuente o API externa de datos cinematográficos, utilizada para mantener actualizado el catálogo base de la plataforma. 

CineMatch  contempla  dos  roles  principales:  usuario  y  administrador.  El  usuario  puede consultar información sobre películas y series, expresar sus opiniones, establecer relaciones con  otros  usuarios  y  compartir  recomendaciones  de  acuerdo  con  las  funcionalidades disponibles en el sistema. También puede consultar recomendaciones procedentes de su red de amigos o de la comunidad, según sus necesidades de exploración. Por su parte, el administrador  es  responsable  de  mantener  actualizado  el  catálogo  base  y  moderar  las reseñas  publicadas,  contribuyendo  al  mantenimiento  y  organización  de  la  información disponible en la plataforma. 

El desarrollo de CineMatch requiere establecer de manera clara las funcionalidades que debe ofrecer el sistema, las condiciones bajo las cuales deben ejecutarse y las restricciones que  orientan su  funcionamiento. Por  esta razón,  el  presente  documento  especifica  los requisitos de software que servirán como referencia para el diseño, desarrollo y verificación de la plataforma. En él se describen el sistema y sus objetivos, los usuarios y sus roles, los requisitos  funcionales  y  no  funcionales,  las  reglas  de  negocio,  los  diagramas  y  la documentación de casos de uso, el modelo entidad-relación, los diagramas de secuencia y el diccionario de datos. 

<a name="_page3_x82.00_y70.92"></a>**1. Planteamiento del problema** 

La elección de una película o serie puede convertirse en un proceso prolongado cuando existe una amplia variedad de títulos disponibles y el usuario no cuenta con información suficiente para determinar cuáles se ajustan a sus preferencias. Aunque las plataformas digitales ofrecen catálogos, sinopsis, calificaciones y reseñas, la cantidad de alternativas e información disponible puede dificultar la selección. Además, las calificaciones promedio ofrecen una referencia general, mientras que las reseñas, aunque proporcionan mayor contexto,  pueden  requerir  tiempo  de  lectura  y  provenir  de  personas  cuyos  gustos  no coinciden con los del usuario. 

Por otra parte, las recomendaciones realizadas entre amigos y conocidos constituyen una fuente de información basada en la confianza y en el conocimiento de los gustos personales. Sin embargo, suelen compartirse mediante conversaciones o aplicaciones de mensajería externas, por lo que la recomendación puede quedar separada de la información del título, del motivo que explica la recomendación y del seguimiento posterior de la experiencia del destinatario.  Esto  dificulta  conservar,  organizar  y  consultar  posteriormente  las recomendaciones recibidas. Además, al no existir un espacio específico para gestionar estas interacciones, el usuario puede perder fácilmente el contexto de por qué un título fue recomendado o cuál fue su experiencia después de verla. 

Asimismo, depender exclusivamente de las recomendaciones personales puede limitar las posibilidades de descubrimiento para quienes no cuentan con una red de amigos dentro de una  plataforma.  En  estos  casos,  el  usuario  debe  recurrir  a  búsquedas  generales, calificaciones promedio o reseñas de otros usuarios para encontrar nuevas opciones, sin contar  necesariamente  con  una  forma  sencilla  de  relacionar  esta  información  con  sus propios  intereses.  Por  ello,  resulta  conveniente  complementar  las  recomendaciones individuales con información proveniente de una comunidad más amplia, aprovechando las calificaciones y reseñas de otros usuarios para encontrar nuevas opciones. 

Ante esta problemática, se identifica la necesidad de una plataforma que reúna la consulta de películas y series, las opiniones de los usuarios y las recomendaciones en un mismo entorno.  CineMatch  se  plantea  como  una  respuesta  mediante  la  integración  de recomendaciones  entre  amigos  y  recomendaciones  generales  de  la  comunidad, acompañadas de reseñas, calificaciones y etiquetas que faciliten la interpretación de las opiniones. Además, incorpora una biblioteca personal, categorías de interés y notificaciones que permiten organizar la interacción alrededor de los títulos recomendados y facilitar el proceso de elección del usuario. De esta manera, se busca reducir el tiempo y la dificultad asociados  a  la  búsqueda  de  títulos,  proporcionando  un  entorno  en  el  que  las recomendaciones  puedan  ser  consultadas,  comprendidas  y  gestionadas  de  forma organizada. 

1. **Justificación**

<a name="_page4_x82.00_y70.92"></a>El desarrollo de CineMatch se justifica por la necesidad de reducir la indecisión al elegir una película  o  serie.  Al  combinar  recomendaciones  de  amigos  con  recomendaciones  de  la comunidad, el usuario cuenta con criterios claros para decidir en menos tiempo y con mayor confianza. 

La recomendación dirigida aporta un valor que un catálogo con calificaciones promedio no ofrece: llega de una persona conocida, trae el contexto de por qué se recomienda (un motivo opcional y, si el emisor lo desea, su reseña) y tiene en cuenta los intereses del destinatario, ya que el sistema avisa cuando el título no coincide con las categorías que este sigue. La calificación y las etiquetas resumen las razones de quien recomienda y facilitan la lectura rápida, lo que permite decidir antes de revisar la reseña completa. 

La plataforma también es útil para quien apenas comienza y aún no tiene amigos en ella. Las recomendaciones generales, filtrables por género, permiten obtener sugerencias desde el  primer  uso  y  exploraciones  más  allá  del  círculo  cercano,  y  los  intereses  elegidos  al registrarse ayudan a orientarlas incluso cuando la comunidad aún tiene pocas reseñas. 

Finalmente,  las  notificaciones  en  tiempo  real  cierran  el  ciclo  de  la  recomendación:  el destinatario sabe cuándo recibe una sugerencia y quien la envió sabe cuándo su amigo la aceptó o la completó (la vio y la calificó). Esta retroalimentación incentiva la participación y mejora  la calidad  de  las  recomendaciones  futuras. Desde  el  punto  de  vista técnico,  el proyecto  integra  gestión  de  usuarios  y  relaciones  entre  ellos,  consumo  de  una  fuente externa de datos, notificaciones en tiempo real y agregación de calificaciones, lo que lo hace un caso completo para la especificación y el diseño de un sistema software. 

2. **Objetivo<a name="_page5_x82.00_y70.92"></a> general**

Desarrollar una plataforma web que permita a los usuarios calificar y reseñar películas y series y recomendárselas entre sí de forma dirigida y con contexto, complementada con recomendaciones  generales  construidas  a  partir  de  las  calificaciones  y  reseñas  de  la comunidad, para facilitar la elección de qué película o serie ver. 

3. **Objetivos<a name="_page5_x82.00_y190.92"></a> específicos** 
1. Gestionar los usuarios y su red de amigos o conexiones, permitiendo el registro con username único y selección de categorías de interés, la administración del perfil y el envío, cancelación, aceptación o rechazo de solicitudes de amistad. 
1. Ofrecer un catálogo de películas y series con búsqueda y filtrado por tipo y género, alimentado y mantenido desde una fuente o API externa de datos de cine. 
1. Permitir la calificación (de 1 a 5) y la reseña de títulos, con visibilidad pública o solo para  amigos  y  etiquetas  que  resuman  cada  reseña,  y  mantener  una  biblioteca personal con el estado de cada título (pendiente, viendo, vista o abandonada). 
1. Implementar  las  recomendaciones  dirigidas  entre  amigos,  que  consideran  los intereses del destinatario, y las recomendaciones generales de la comunidad, con notificaciones  en  tiempo  real  sobre  el  ciclo  de  cada  recomendación  (recibida, aceptada y completada). 

<a name="_page6_x82.00_y70.92"></a>**2. Especificación de Requisitos de Software**

1. **Descripción<a name="_page6_x82.00_y112.92"></a> del sistema**

CineMatch es una plataforma web de recomendación y reseñas de películas y series que permite a los usuarios recomendarse títulos entre sí de forma dirigida y con contexto, y que complementa esas recomendaciones con las de la comunidad. En esta versión cada serie se maneja como una sola unidad, sin temporadas ni episodios. El sistema está compuesto por los siguientes módulos: 

- **Módulo de gestión de usuarios:** registro con username único y selección de al menos 3 géneros de interés, recuperación de contraseña, perfil (avatar y biografía) y manejo de la red de amigos. 
- **Módulo de catálogo:** listado de películas y series con búsqueda y filtrado por tipo y género, alimentado desde una fuente o API externa. 
- **Módulo de reseñas y calificaciones:** permite calificar un título de 1 a 5, escribir una reseña con visibilidad pública o solo para amigos, marcarla como spoiler y asociarle hasta 5 etiquetas. 
- **Módulo de biblioteca personal:** permite marcar cada título como pendiente, viendo, vista o abandonada y consultarlos por pestañas, con filtros y orden. 
- **Módulo de recomendaciones dirigidas:** permite recomendar un título a un amigo con un motivo opcional y, si se desea, adjuntando la reseña propia. La lista de amigos se ordena según la coincidencia con sus intereses y avisa cuando el título está fuera de ellos. 
- **Módulo de recomendaciones generales (comunidad):** agrega las calificaciones y las etiquetas de la comunidad para sugerir títulos a cualquier persona, con o sin amigos en la plataforma, filtrables por género. 
- **Módulo  de  notificaciones  en  tiempo  real:**  informa  cuando  se  recibe,  acepta  o completa una recomendación, cuando llega o se acepta una solicitud de amistad y cuando una reseña es ocultada. 
- **Módulo de administración:** mantenimiento del catálogo base desde la API externa y moderación de reseñas. 

El software busca resolver el problema de la indecisión al elegir qué película o serie ver, apoyándose en dos fuentes de recomendación: la opinión de personas cercanas (amigos), cuando el usuario ya tiene una red de contactos, y la opinión agregada de la comunidad, cuando no la tiene o quiere explorar más allá de su círculo. Las recomendaciones llegan con la calificación y las etiquetas de quien recomienda, de forma que el receptor pueda decidir rápidamente si el título le interesa antes de leer la reseña completa. 

2. **Objetivo<a name="_page7_x82.00_y70.92"></a> del sistema**

El sistema busca ofrecer una solución sencilla y confiable para decidir qué película o serie ver, combinando las recomendaciones dirigidas entre amigos, que consideran los intereses de  quien  las  recibe,  con  las  recomendaciones  generales  de  la  comunidad.  CineMatch pretende reducir el tiempo de decisión del usuario, aprovechar la confianza en las personas cercanas  y  mantener  informados  a  todos  los  participantes  mediante  notificaciones  en tiempo real. 

3. **Análisis<a name="_page7_x82.00_y217.92"></a> de usuarios**

CineMatch está pensado para un público general de aficionados al cine y las series. Se identifican dos roles principales dentro del sistema y un actor externo, que intervienen de la siguiente manera: 

- **Usuario:** persona registrada que explora el catálogo, construye su biblioteca, califica y reseña títulos, y se recomienda contenido con sus amigos y con la comunidad. 
- **Administrador:** encargado de mantener el catálogo base y de moderar las reseñas publicadas. 
- **API externa de datos de cine:** sistema externo que provee los datos del catálogo; no es un rol de usuario. 

<a name="_page7_x82.00_y437.92"></a>**2.3.1 Descripción de roles**

A continuación, se detallan las funciones a las que accede cada rol: 

- **Usuario:** puede registrar su cuenta con username único y elegir sus intereses, iniciar sesión y recuperar su contraseña, editar su perfil, consultar y filtrar el catálogo, ver la ficha de un título, buscar usuarios y gestionar sus amigos, calificar y reseñar títulos (y  editar  o  eliminar  sus  reseñas),  llevar  su  biblioteca,  recomendar  títulos  a  sus amigos y gestionar las recomendaciones que envía y recibe, consultar y marcar sus notificaciones, consultar las recomendaciones generales y ver su perfil o el de otros usuarios según las reglas de privacidad. 
- **Administrador:** puede iniciar y cerrar sesión, actualizar y mantener el catálogo base de películas y series y moderar (ocultar o restablecer) las reseñas realizadas por los usuarios. 

La  **API  externa  de  datos  de  cine**  corresponde  a  un  sistema  externo  que  proporciona información para alimentar el catálogo base, como tipo (película o serie), título, sinopsis, géneros, año, director o creador, duración y póster. Esta fuente se considera un actor externo del sistema y no un rol de usuario. 

4. **Requisitos<a name="_page8_x82.00_y70.92"></a> funcionales**

Los requisitos funcionales que describen el comportamiento del software se detallan en la siguiente tabla. La prioridad indica el alcance de la primera entrega: Alta corresponde al núcleo imprescindible (MVP) y Media a funciones deseables que se implementan una vez completado el núcleo. Las funciones de fases posteriores se describen en 2.4.3 y las reglas que las gobiernan, en 2.4.2. 



|**ID**|**Descripción del Requisito Funcional**|**Datos de Entrada**|**Datos de Salida**|**Prioridad**|**Estado**|
| - | :-: | :- | - | - | - |
|RF1|Registro de una cuenta con username único y creación del perfil de usuario.|Nombre, username, correo y contraseña|Cuenta creada y perfil disponible|Alta|Pendiente|
|RF2|Selección de intereses (al menos 3 géneros) al registrarse y modificación posterior.|Géneros seleccionados|Intereses del usuario guardados|Alta|Pendiente|
|RF3|Inicio y cierre de sesión de los usuarios y del administrador, con límite de intentos fallidos y expiración de la sesión.|Correo y contraseña|Acceso concedido o mensaje de error; sesión cerrada|Alta|Pendiente|
|RF4|Recuperación de la contraseña mediante un enlace de un solo uso enviado al correo.|Correo; nueva contraseña|Contraseña actualizada|Media|Pendiente|
|RF5|Consulta y edición del perfil propio (nombre, username, avatar, biografía, intereses y contraseña).|Datos del perfil|Perfil actualizado|Media|Pendiente|
|RF6|Consulta del catálogo general de películas y series.|Solicitud de listado|Listado paginado del catálogo|Alta|Pendiente|
|RF7|Búsqueda y filtrado de títulos por texto, tipo (película o serie) y género.|Texto de búsqueda, tipo y género(s)|Listado del catálogo filtrado|Alta|Pendiente|
|RF8|Consulta de la ficha de un título: póster, sinopsis, duración, calificación promedio de la comunidad, calificación de los amigos, etiquetas más repetidas y reseñas visibles para el usuario.|ID del título|Ficha completa del título|Alta|Pendiente|
|RF9|Búsqueda de usuarios por username.|Texto de búsqueda|Lista de usuarios coincidentes|Alta|Pendiente|
|RF10|Gestión de amistades: enviar, cancelar, aceptar o rechazar solicitudes y eliminar amigos.|Usuario destino y acción|Solicitud registrada y red de amigos actualizada|Alta|Pendiente|



|**ID**|**Descripción del Requisito ![ref1]Funcional**|**Datos de Entrada**|**Datos de Salida**|**Prioridad**|**Estado**|
| - | :-: | :- | - | - | - |
|RF11|Calificación de un título de 1 a 5 (pasos de 0,5) y escritura opcional de una reseña, con visibilidad pública o solo para amigos y marca de spoiler.|ID del título, calificación, comentario, visibilidad y spoiler|Confirmación de la reseña publicada|Alta|Pendiente|
|RF12|Asociación de hasta 5 etiquetas (tags o palabras de la propia reseña) a una reseña.|Reseña y etiquetas|Reseña con etiquetas asociadas|Alta|Pendiente|
|RF13|Edición y eliminación de las reseñas propias.|ID de la reseña y cambios|Reseña actualizada o eliminada|Media|Pendiente|
|RF14|Gestión de la biblioteca personal: marcar un título como pendiente, viendo, vista o abandonada y consultarlos por pestañas, con filtros y orden.|ID del título y estado|Biblioteca actualizada|Alta|Pendiente|
|RF15|Recomendación dirigida de un título a un amigo, con motivo opcional y reseña adjunta opcional. La lista de amigos se ordena por coincidencia con los intereses, avisa si el título está fuera de ellos y excluye a quienes ya lo vieron.|ID del título, ID del amigo, motivo y reseña (opcionales)|Confirmación de recomendación enviada|Alta|Pendiente|
|RF16|Gestión de las recomendaciones recibidas: abrir, agregar a pendientes (aceptar), descartar y completar al calificar el título.|ID de la recomendació n y acción|Estado de la recomendación actualizado|Alta|Pendiente|
|RF17|Consulta de las recomendaciones enviadas y su estado.|Solicitud de recomendacio nes enviadas|Lista de recomendacion es con su estado|Media|Pendiente|
|RF18|Generación de notificaciones en tiempo real: recomendación recibida, aceptada y completada, solicitud y aceptación de amistad, y reseña oculta.|Evento del sistema|Notificación entregada al destinatario|Alta|Pendiente|
|RF19|Consulta de notificaciones y marcado como leídas.|Solicitud de notificaciones|Lista de notificaciones y estado de lectura|Media|Pendiente|
|RF20|Consulta de recomendaciones generales de la comunidad, para usuarios con o sin amigos, filtrables por género.|Género (opcional)|Lista de títulos recomendados por la comunidad|Alta|Pendiente|
|RF21|Consulta del perfil de otro usuario según las reglas de privacidad (no amigo: datos básicos y reseñas públicas; amigo: además biblioteca y pendientes).|ID del usuario consultado|Perfil con la información permitida|Media|Pendiente|



|**ID**|**Descripción del Requisito ![ref1]Funcional**|**Datos de Entrada**|**Datos de Salida**|**Prioridad**|**Estado**|
| - | :-: | :- | - | - | - |
|RF22|Actualización y mantenimiento del catálogo base desde una fuente o API externa de datos de cine (administrador).|Datos de la fuente externa (tipo, título, sinopsis, géneros, año, director o creador, duración y póster)|Catálogo actualizado y resumen del proceso|Alta|Pendiente|
|RF23|Moderación del contenido de las reseñas: ocultar o restablecer (administrador).|ID de la reseña y decisión|Reseña ocultada o restablecida|Media|Pendiente|

1. **Requisitos<a name="_page10_x82.00_y273.92"></a> no funcionales** 

Los requisitos no funcionales que permiten optimizar la operación del sistema desde el punto de vista de las características de calidad del software se listan en la siguiente tabla. 



|**Requerimiento NF**|**Descripción**|
| - | - |
|**Rendimiento**|<p>- Tiempo de respuesta promedio ≤ 2 segundos en la consulta del catálogo, la búsqueda, el filtrado y las recomendaciones generales bajo carga normal (estas últimas se precalculan y se sirven desde caché).</p><p>- Las notificaciones en tiempo real deben ser entregadas en un máximo de 5 segundos al usuario conectado.</p>|
|**Seguridad**|<p>- Las contraseñas deben almacenarse con una función de hash con sal (por ejemplo, bcrypt) y las comunicaciones deben utilizar HTTPS/TLS.</p><p>- El sistema debe implementar autenticación y control de acceso según los roles de usuario y administrador.</p><p>- Tras 5 intentos fallidos de inicio de sesión, la cuenta se bloquea temporalmente por 15 minutos; la sesión expira tras 30 minutos de inactividad.</p><p>- Todo texto ingresado por los usuarios (reseñas, motivos, biografía) debe sanitizarse y escaparse para evitar XSS, y las consultas a la base de datos deben ser parametrizadas.</p><p>- Cada usuario solo podrá modificar su propio perfil, calificaciones, reseñas y biblioteca.</p><p>- La visibilidad de perfiles, biblioteca y reseñas sigue las reglas de privacidad de la sección 2.4.2.</p><p>- Las recomendaciones dirigidas solo serán visibles para el usuario que las envía y el usuario que las recibe.</p><p>- Los enlaces de recuperación de contraseña son de un solo uso y vencen en 1 hora.</p><p>- El tratamiento de datos personales debe cumplir la Ley 1581 de 2012: autorización del titular al registrarse y posibilidad de consultar, actualizar y eliminar sus datos.</p>|
|**Disponibilidad**|<p>- Disponibilidad del sistema del 99 %, excluyendo mantenimientos programados.</p><p>- Se realizará una copia de seguridad diaria de la base de datos, con una retención mínima de 30 días.</p>|



|**Requerimiento NF**|**Descripción**|
| - | - |
|**Usabilidad**|<p>- Las acciones principales (marcar el estado de un título, calificarlo y recomendarlo) deben poder realizarse en un máximo de 3 clics desde la ficha del título.</p><p>- La calificación y las etiquetas deben mostrarse antes de la reseña completa, y las reseñas marcadas como spoiler deben ocultarse tras una advertencia.</p><p>- Los mensajes de error deben indicar el campo o la acción que se debe corregir.</p>|
|**Compatibilidad**|<p>- El sistema debe funcionar en las dos últimas versiones estables de Google Chrome, Mozilla Firefox, Microsoft Edge y Safari.</p><p>- La interfaz debe contar con diseño responsivo para su utilización en computador, tablet y celular (desde 360 px de ancho).</p>|
|**Escalabilidad**|<p>- El sistema debe permitir el crecimiento en cantidad de usuarios, reseñas y recomendaciones sin degradar significativamente el servicio.</p><p>- Se establece como meta inicial soportar 100 usuarios concurrentes sin pérdida de rendimiento.</p>|
|**Mantenibilidad**|- El código debe estar organizado por módulos, siguiendo buenas prácticas de desarrollo y contando con la documentación necesaria para facilitar su mantenimiento y modificación.|
|**Internacionalización**|- La interfaz debe permitir la adaptación de textos, formatos de fecha y otros elementos necesarios para incorporar diferentes idiomas y configuraciones regionales en futuras versiones.|
|**Accesibilidad**|- Las funciones principales deben cumplir el nivel AA de las pautas WCAG 2.1: contraste suficiente, navegación por teclado y texto alternativo en pósteres y avatares.|
|**Integración**|<p>- El sistema debe integrarse con una fuente o API externa de datos de cine para alimentar y mantener actualizado el catálogo base.</p><p>- Si la fuente externa no responde temporalmente, el sistema debe continuar operando con la información del catálogo previamente almacenada.</p>|
2. **Reglas<a name="_page12_x82.00_y70.92"></a> de negocio** 

Las siguientes reglas completan los requisitos funcionales y deben respetarse en el diseño, la implementación y las pruebas del sistema. 



|**ID**|**Regla**|**Descripción**|
| - | - | - |
|RN1|Calificación|Va de 1 a 5, en pasos de 0,5. Cada usuario tiene como máximo una reseña (calificación y comentario opcional) por título, que puede editar o eliminar.|
|RN2|Calificar implica ver|Al calificar un título, el sistema lo marca como “vista” en la biblioteca del usuario si no lo estaba.|
|RN3|Visibilidad de la reseña|El autor elige entre pública o solo para amigos y puede cambiarla después. El comentario, las etiquetas y la identidad del autor de una reseña “solo amigos” únicamente se muestran a sus amigos.|
|RN4|Promedio y ranking|La calificación de toda reseña no oculta cuenta para el promedio y el ranking públicos, sea pública o solo para amigos; en el promedio se muestra de forma agregada, sin identificar a su autor. Las reseñas ocultas por moderación se excluyen del promedio, del ranking, de las etiquetas de la comunidad y de las recomendaciones generales.|
|RN5|Calificación de amigos|La ficha muestra aparte el promedio de las calificaciones de los amigos del usuario (por ejemplo, “tus amigos: 4,2”), calculado con sus reseñas públicas y solo para amigos.|
|RN6|Etiquetas|Una reseña con comentario admite hasta 5 etiquetas: tags o palabras cortas (máximo 30 caracteres) tomadas de su propio texto. Se normalizan (minúsculas, sin tildes ni espacios sobrantes) para poder compararlas entre reseñas.|
|RN7|Lo que más dice la comunidad|La ficha muestra como términos fuertes las etiquetas que coinciden en al menos N reseñas públicas y visibles del mismo título (N = 3 por defecto, parametrizable). Las etiquetas de reseñas “solo amigos” no se cuentan, para no exponer su contenido.|
|RN8|Spoilers|Si el autor marca la reseña como spoiler, su comentario se oculta tras una advertencia hasta que el lector decida mostrarlo.|
|RN9|Perfil y privacidad|Quien no es amigo ve solo los datos básicos (nombre, username, avatar y biografía), las reseñas públicas y el botón para enviar la solicitud de amistad. Los amigos ven además las reseñas “solo amigos”, la biblioteca y los pendientes.|
|RN10|Amistad|No se permite agregarse a sí mismo, repetir una solicitud ni enviar una solicitud inversa (A→B y B→A) cuando ya existe una. El solicitante puede cancelar una solicitud pendiente, cualquiera de los dos puede eliminar la amistad y una solicitud rechazada puede volver a enviarse.|
|RN11|Recomendar|Solo se recomienda a amigos, nunca a uno mismo, y una sola vez por combinación de emisor, receptor y título. No se puede recomendar un título a un amigo que ya lo vio; en la lista aparece marcado como “ya la vio”. El motivo es opcional (hasta 500 caracteres) y la reseña adjunta, también opcional, debe ser del emisor. No se exige tener una reseña previa.|



|**ID**|**Regla**|**Descripción**|
| - | - | - |
|RN12|Selección según intereses|Al recomendar, primero aparecen los amigos cuyos intereses coinciden con algún género del título, ordenados por cantidad de géneros en común, y luego “otros amigos”. Si el emisor elige a uno de estos últimos, el sistema le avisa de que no sigue esa categoría y le permite continuar. El indicador fueraDeIntereses se guarda al momento del envío, porque los intereses pueden cambiar después, y el receptor ve la etiqueta “no coincide con tus intereses”.|
|RN13|Intereses|Se eligen al menos 3 géneros al crear la cuenta y pueden modificarse después sin bajar de ese mínimo.|
|RN14|Moderación y recomendaciones|Si una reseña se oculta o se elimina, las recomendaciones que la adjuntaban se conservan y muestran solo el motivo. El autor recibe una notificación cuando su reseña es ocultada.|
|RN15|Recomendaciones generales|Se ordenan por promedio de calificaciones con un mínimo de calificaciones por título (5 por defecto, parametrizable), excluyen las reseñas ocultas y los títulos que el usuario ya vio, y priorizan sus géneros de interés. Cuando no hay suficientes calificaciones (arranque en frío), se completan con la popularidad que reporta la API externa. El resultado se precalcula cada hora y se guarda en caché para cumplir el tiempo de respuesta.|
|RN16|Series y catálogo|En esta versión una serie se trata como una sola unidad, sin temporadas ni episodios; el campo tipo diferencia película y serie. Un título se identifica de forma única por la combinación de fuente, tipo e identificador externo.|
|RN17|Username|Tiene entre 3 y 20 caracteres (letras, números y guion bajo) y es único sin distinguir mayúsculas.|

**Estados de la recomendación** 



|**Estado**|**Significado**|**Cómo se llega**|
| - | - | - |
|enviada|Creada; el receptor aún no la ha abierto.|Al enviarla el emisor.|
|abierta|El receptor consultó el detalle de la recomendación.|Al abrirla el receptor.|
|aceptada|El título quedó en los pendientes del receptor.|Al agregarla a pendientes desde la recomendación.|
|descartada|El receptor indicó “no me interesa”.|Acción del receptor.|
|completada|El receptor vio el título y lo calificó.|Al marcarlo como visto y calificarlo, desde la recomendación o por su cuenta.|

El flujo normal es enviada → abierta → aceptada o descartada → completada. El estado completada se activa cuando el receptor califica el título, aunque no escriba comentario; si lo escribe, el emisor lo ve al abrir la notificación. Si el receptor ve y califica el título por su cuenta, pasan a completada todas las recomendaciones de ese título que estén en estado enviada, abierta o aceptada, y cada emisor recibe su aviso. Las recomendaciones descartadas no cambian de estado. 

**Tipos de notificación** 



|**Tipo**|**Destinatario**|**Cuándo se genera**|
| - | - | - |
|recomendacion\_recibida|Receptor|Al enviarse la recomendación. Incluye el aviso de fuera de intereses cuando aplica.|
|recomendacion\_aceptada|Emisor|El receptor guardó el título en sus pendientes.|
|recomendacion\_completa da|Emisor|El receptor vio y calificó el título. Incluye su calificación y su comentario si lo dejó.|
|solicitud\_amistad|Receptor de la solicitud|Al enviarse una solicitud de amistad.|
|amistad\_aceptada|Solicitante|Al aceptarse la solicitud de amistad.|
|resena\_oculta|Autor de la reseña|Cuando el administrador oculta su reseña.|

Cada evento genera una notificación independiente, con su estado de lectura. Descartar una recomendación no genera notificación, para evitar fricción social. En esta versión, abrir una recomendación  tampoco  genera  aviso;  podría  ofrecerse  más  adelante  como  opción desactivada por defecto. 

3. **Alcance<a name="_page14_x82.00_y387.92"></a> por fases** 

Para no inflar el alcance de la primera entrega, los requisitos de la sección 2.4 y el modelo de datos de la sección 2.9 corresponden a la Fase 1. Las demás funcionalidades se plantean como evolución del producto: 

- **Fase 1 (núcleo):** catálogo de películas y series, intereses, reseñas con calificación, etiquetas y spoilers, biblioteca personal, recomendaciones dirigidas con contexto, recomendaciones generales, notificaciones, amistades y perfil. 
- **Fase 2 (social):** feed de actividad de los amigos; “pedir recomendación” dirigida a amigos (por ejemplo, “hoy quiero una comedia”); comentarios y “útil/me gusta” en las reseñas; listas personalizadas y compartidas; recomendar a varios amigos a la vez; reportar reseñas, con su tabla de reportes para facilitar la moderación; y temporadas y episodios con progreso para las series. 
- **Fase 3 (diferenciadores):** porcentaje de afinidad entre amigos según calificaciones coincidentes; recomendaciones personalizadas por intereses e historial; dónde ver el título y títulos similares, según la API elegida; estadísticas personales (“tu año en cine”) y notificaciones por correo. 
5. **Diagrama<a name="_page15_x82.00_y70.92"></a> de caso de uso**

El comportamiento del sistema CineMatch en relación con la interacción con el usuario se muestra en el siguiente diagrama. Consultar catálogo, buscar y filtrar se documenta como un  solo caso  de  uso. Las  relaciones  con  los  casos  complementarios  son  las  siguientes: Seleccionar  intereses  está  incluido  en Registrar cuenta;  Recuperar contraseña extiende Iniciar sesión; Buscar usuarios y Enviar o responder solicitud están incluidos en Gestionar amigos;  Etiquetar  reseña  está  incluido  en  Calificar  y  reseñar;  Seleccionar  amigo  según intereses está incluido en Recomendar un título a un amigo, y Adjuntar reseña lo extiende de forma opcional; y Notificar al emisor extiende Gestionar recomendaciones recibidas cuando el receptor acepta o completa una recomendación. 

![](Aspose.Words.69a4485e-d3ec-40ea-8322-cb0ba1e26bc0.003.jpeg)

***Figura 1.** Diagrama de casos de uso del Usuario*

Las funcionalidades del administrador y su relación con la API externa de datos de cine, que actúa  como  actor  secundario  durante  la  actualización  del  catálogo,  se  muestran  en  el siguiente diagrama. 

![](Aspose.Words.69a4485e-d3ec-40ea-8322-cb0ba1e26bc0.004.jpeg)

***Figura 2.** Diagrama de casos de uso del Administrador*

6. **Documentación<a name="_page17_x82.00_y70.92"></a> de casos de uso**

A continuación, se especifica cada caso de uso mediante una tabla de pasos, indicando el evento, la acción del actor y el resultado esperado del sistema. 

**Especificación de casos de uso con las funcionalidades del Usuario** 

1. **Registrar cuenta, elegir intereses y crear perfil:** Permite a una persona crear su cuenta con un username único, elegir sus géneros de interés y generar su perfil, requisito para usar el resto de las funciones. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Acceso al registro|El usuario selecciona la opción de registrarse|El sistema muestra el formulario de registro|
|2|Ingreso de datos|El usuario completa nombre, username (3 a 20 caracteres), correo y contraseña, y autoriza el tratamiento de sus datos personales|El sistema valida el formato y que el correo y el username (sin distinguir mayúsculas) no estén registrados|
|3|Error de validación|<p>El usuario envía datos inválidos, </p><p>o un correo o username ya registrado</p>|El sistema muestra un mensaje de error indicando el campo a corregir|
|4|Selección de intereses|El usuario selecciona al menos 3 géneros de interés|El sistema valida la cantidad mínima y guarda los intereses|
|5|Creación de cuenta|El usuario confirma el registro|El sistema crea la cuenta y el perfil y permite iniciar sesión|

2. **Iniciar  sesión:**  Permite  al  usuario  acceder  a  su  cuenta  en  CineMatch  mediante  sus credenciales. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Inicio de sesión|El usuario ingresa correo y contraseña|El sistema valida las credenciales|
|2|Validación exitosa|Ninguna|El sistema concede el acceso, inicia la sesión y muestra la pantalla principal|
|3|Error en validación|Ninguna|El sistema muestra un mensaje de error si las credenciales son incorrectas|
|4|Bloqueo temporal|El usuario supera 5 intentos fallidos consecutivos|El sistema bloquea nuevos intentos por 15 minutos e informa al usuario|
|5|Sesión expirada|El usuario permanece 30 minutos sin actividad|El sistema cierra la sesión y solicita iniciar sesión de nuevo|

3. **Recuperar  contraseña:**  Permite  al  usuario  que  olvidó  su  contraseña  restablecerla mediante un enlace enviado a su correo. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Solicitud|El usuario selecciona “Olvidé mi contraseña” e ingresa su correo|El sistema responde con un mensaje neutro, exista o no el correo, y si existe envía un enlace de un solo uso con vigencia de 1 hora|
|2|Restablecimiento|El usuario abre el enlace e ingresa una nueva contraseña|El sistema valida el token y los requisitos de la contraseña|
|3|Enlace inválido|<p>El usuario usa un enlace vencido </p><p>o ya utilizado</p>|El sistema informa del problema y permite solicitar uno nuevo|
|4|Confirmación|Ninguna|El sistema guarda la nueva contraseña como hash, invalida el enlace y las sesiones activas e informa al usuario|

4. **Consultar catálogo, buscar y filtrar:** Permite explorar el catálogo de películas y series, buscar por título y filtrar por tipo y género. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Acceso al catálogo|El usuario ingresa a la sección de catálogo|El sistema muestra el listado paginado de títulos con póster, nombre y año|
|2|Búsqueda|El usuario escribe un título o palabra de búsqueda|El sistema muestra los títulos que coinciden|
|3|Filtros|El usuario selecciona el tipo (película o serie) y uno o varios géneros|El sistema muestra solo los títulos que cumplen los criterios|
|4|Sin resultados|Ninguna|El sistema informa que no hay títulos con esos criterios|

5. **Consultar ficha de un título:** Permite ver la información completa de una película o serie y la opinión de la comunidad y de los amigos sobre ella. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Selección del título|El usuario selecciona un título del catálogo, de una recomendación, de una biblioteca o de un perfil|El sistema muestra la ficha del título|
|2|Información básica|Ninguna|La ficha incluye póster, título, tipo, sinopsis, géneros, año, director o creador, duración y calificación promedio de la comunidad|
|3|Calificación de amigos|Ninguna|Si algún amigo lo calificó, el sistema muestra aparte su promedio (por ejemplo, “tus amigos: 4,2”)|
|4|Etiquetas de la comunidad|Ninguna|El sistema muestra las etiquetas que más coinciden entre las reseñas públicas (“lo que más dice la comunidad”)|
|5|Reseñas|El usuario revisa las reseñas de otros usuarios|El sistema muestra las reseñas públicas y las de sus amigos, con la calificación y las etiquetas antes del comentario; las marcadas como spoiler se ocultan tras una advertencia y las ocultas por moderación no se muestran|
|6|Acciones disponibles|El usuario elige calificar, reseñar, marcar su estado o recomendar el título|El sistema dirige al caso de uso correspondiente|

6. **Gestionar amigos:** Permite al usuario construir su red de amigos buscando personas, enviando solicitudes, respondiendo las que recibe y eliminando amistades. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Búsqueda|El usuario busca a otra persona por su username|El sistema muestra los usuarios que coinciden, sin incluir al propio usuario|
|2|Envío de solicitud|El usuario selecciona agregarla como amiga|El sistema valida que no exista una solicitud o amistad previa, en ningún sentido, y registra la solicitud como pendiente|
|3|Recepción|Ninguna|El sistema notifica al destinatario y muestra la solicitud en sus solicitudes pendientes|
|4|Respuesta|El destinatario acepta o rechaza la solicitud|El sistema actualiza el estado de la solicitud y, si fue aceptada, notifica al solicitante|
|5|Cancelación|El solicitante cancela una solicitud pendiente|El sistema elimina la solicitud|



|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|6|Eliminar amigo|El usuario elimina a un amigo de su lista|El sistema elimina la amistad; ambos dejan de ver los contenidos restringidos a amigos|
|7|Solicitud inválida|El usuario intenta agregarse a sí mismo o repetir una solicitud|El sistema rechaza la acción e informa al usuario|

7. **Calificar y reseñar un título:** Permite calificar un título de 1 a 5, escribir una reseña con la visibilidad deseada y asociarle etiquetas, así como editarla o eliminarla. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Selección del título|El usuario abre la ficha de un título|El sistema muestra la opción de calificar y reseñar, con los datos actuales si ya existe una reseña|
|2|Calificación|El usuario asigna una puntuación de 1 a 5, en pasos de 0,5|El sistema valida que esté en el rango permitido|
|3|Reseña|El usuario escribe un comentario (opcional), elige la visibilidad (pública o solo amigos) y marca si contiene spoilers|El sistema valida y sanitiza el texto ingresado|
|4|Etiquetas|El usuario selecciona o escribe hasta 5 etiquetas tomadas de su reseña|El sistema las normaliza y las asocia a la reseña|
|5|Publicación|El usuario confirma|El sistema guarda la reseña y sus etiquetas, marca el título como visto, actualiza el promedio y completa las recomendaciones pendientes de ese título (ver caso de uso 10)|
|6|Edición o eliminación|El usuario modifica o elimina su reseña|<p>El sistema registra la fecha de edición </p><p>o elimina la reseña, y recalcula el promedio</p>|
|7|Error de validación|El usuario envía una calificación fuera de rango o más de 5 etiquetas|El sistema muestra un mensaje de error indicando qué corregir|

8. **Gestionar biblioteca personal:** Permite llevar el seguimiento de los títulos del usuario según su estado. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Marcar estado|El usuario elige un título (del catálogo, de una ficha o de una recomendación) y selecciona pendiente, viendo, vista o abandonada|El sistema registra o actualiza el estado en la biblioteca del usuario|
|2|Calificación al marcar vista|Si marca el título como visto, puede calificarlo y reseñarlo|El sistema dirige al caso de uso 7|
|3|Consulta|El usuario abre su biblioteca|El sistema muestra pestañas por estado, con filtros por tipo y género y orden por fecha o título|
|4|Quitar título|El usuario quita un título de su biblioteca|El sistema elimina el registro|
|5|Privacidad|Ninguna|La biblioteca solo es visible para su propietario y para sus amigos|

9. **Recomendar un título a un amigo:** Permite recomendar una película o serie a un amigo, con un motivo opcional y la reseña propia como adjunto opcional, teniendo en cuenta los intereses del amigo. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Inicio|El usuario selecciona un título y la opción de recomendar|El sistema muestra a los amigos en dos grupos: primero los que tienen intereses en algún género del título, ordenados por cantidad de géneros en común, y luego “otros amigos”|
|2|Amigos que ya lo vieron|Ninguna|El sistema marca a esos amigos como “ya la vio” y no permite seleccionarlos|
|3|Selección de amigo|El usuario elige al amigo destinatario|Si el amigo es de “otros amigos”, el sistema avisa de que no sigue esa categoría y permite continuar|
|4|Motivo y reseña|El usuario escribe un motivo opcional (hasta 500 caracteres) y, si lo desea, adjunta su reseña del título|El sistema valida la longitud y que la reseña sea del emisor|
|5|Envío|El usuario confirma el envío|El sistema valida la amistad y que no exista una recomendación previa del mismo título al mismo amigo; registra la recomendación como enviada, guarda si está fuera de intereses y envía la notificación|
|6|Confirmación|Ninguna|El sistema muestra un mensaje de recomendación enviada|

10. **Gestionar recomendaciones recibidas:** Permite ver las recomendaciones que los amigos enviaron al usuario, con el contexto de por qué se las recomendaron, y responderlas. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Acceso|El usuario ingresa a sus recomendaciones recibidas|El sistema muestra el listado con el título, el amigo, el estado y la etiqueta “no coincide con tus intereses” cuando aplica|
|2|Detalle|El usuario selecciona una recomendación|El sistema muestra el motivo y, si hay reseña adjunta, primero la calificación y las etiquetas del amigo; marca la recomendación como abierta|
|3|Aceptar|El usuario elige agregar el título a sus pendientes|El sistema marca la recomendación como aceptada, guarda el título como pendiente y notifica al emisor|
|4|Descartar|El usuario elige “no me interesa”|El sistema marca la recomendación como descartada, sin notificar al emisor|
|5|Completar|El usuario marca el título como visto y lo califica (caso de uso 7)|El sistema marca la recomendación como completada y notifica al emisor con la calificación y el comentario, si lo dejó|
|6|Calificación por cuenta propia|El usuario califica el título sin pasar por la recomendación|El sistema completa todas sus recomendaciones abiertas de ese título y notifica a cada emisor|
|7|Reseña no disponible|Ninguna|Si la reseña adjunta fue eliminada u ocultada, el sistema muestra solo el motivo y conserva la recomendación|
|8|Sin recomendaciones|Ninguna|Si aún no ha recibido recomendaciones, el sistema lo informa y ofrece consultar las recomendaciones generales|

11. **Consultar recomendaciones enviadas:** Permite al usuario ver las recomendaciones que envió y en qué estado se encuentran. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Acceso|El usuario ingresa a sus recomendaciones enviadas|El sistema muestra el listado con el título, el amigo destinatario, el estado y las fechas|
|2|Detalle|El usuario selecciona una recomendación|El sistema muestra el motivo, el estado y, si fue completada, la calificación y el comentario del amigo|
|3|Sin recomendaciones|Ninguna|El sistema informa que aún no ha enviado recomendaciones|

12. **Gestionar notificaciones:** Permite al usuario enterarse en tiempo real de lo que ocurre con sus recomendaciones y amistades, y consultar su historial de avisos. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Generación|<p>Ocurre un evento: recomendación recibida, aceptada o completada, solicitud </p><p>o aceptación de amistad, o reseña ocultada</p>|El sistema genera la notificación correspondiente|
|2|Aviso|El usuario está conectado|El sistema muestra el aviso en tiempo real, en un máximo de 5 segundos|
|3|Consulta|El usuario abre su lista de notificaciones|El sistema muestra las notificaciones ordenadas por fecha, distinguiendo las leídas de las no leídas|
|4|Lectura|El usuario abre una notificación|El sistema muestra el elemento relacionado y la marca como leída|
|5|Usuario desconectado|Ninguna|El sistema conserva la notificación y la muestra al iniciar sesión|

13. **Consultar  recomendaciones  generales:**  Permite  obtener  sugerencias  construidas  a partir de las calificaciones y reseñas públicas de la comunidad, tenga o no amigos en la plataforma. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Acceso|El usuario, con o sin amigos, ingresa a las recomendaciones generales|El sistema muestra los títulos sugeridos por la comunidad, calculados previamente y actualizados cada hora|
|2|Criterio|Ninguna|El listado se ordena por calificación promedio con un mínimo de calificaciones, sin reseñas ocultas ni títulos que el usuario ya vio, y prioriza sus géneros de interés|
|3|Pocas calificaciones|Ninguna|Si la comunidad aún no tiene suficientes calificaciones, el sistema completa con la popularidad de la API externa|
|4|Filtro|El usuario selecciona un género o un tipo|El sistema muestra los títulos recomendados que cumplen el filtro|
|5|Detalle|El usuario selecciona un título|El sistema muestra su ficha con calificación promedio y reseñas|

14. **Consultar y editar perfil:** Permite al usuario ver y editar su perfil y consultar el de otros usuarios según las reglas de privacidad. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Perfil propio|El usuario abre su perfil|El sistema muestra sus datos, username, avatar, biografía, intereses, reseñas y biblioteca|
|2|Edición|El usuario modifica su nombre, avatar, biografía, intereses (mínimo 3) o contraseña|El sistema valida los datos y guarda los cambios|
|3|Perfil de un amigo|El usuario abre el perfil de un amigo|El sistema valida la amistad y muestra los datos básicos, las reseñas (públicas y solo amigos), la biblioteca y los pendientes|
|4|Usuario no amigo|El usuario abre el perfil de alguien que no es su amigo|El sistema muestra solo los datos básicos, el username y las reseñas públicas, junto con el botón para enviar la solicitud de amistad; la biblioteca y los pendientes no se muestran|

15. **Cerrar sesión:** Permite al usuario terminar su sesión de forma segura. 



|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Solicitud de cierre|El usuario selecciona cerrar sesión|El sistema finaliza la sesión|
|2|Redirección|Ninguna|El sistema redirige a la pantalla de inicio de sesión|

**Especificación de casos de uso con las funcionalidades del Administrador** 

1. **Iniciar sesión:** Permite al administrador acceder a su cuenta en CineMatch mediante sus credenciales. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Inicio de sesión|El administrador ingresa correo y contraseña|El sistema valida las credenciales|
|2|Validación exitosa|Ninguna|El sistema concede el acceso y muestra el panel de administración|
|3|Error en validación|Ninguna|El sistema muestra un mensaje de error si las credenciales son incorrectas|

2. **Actualizar el  catálogo  base de películas y  series:**  Permite al administrador cargar  y mantener actualizado el catálogo base desde una fuente o API externa de datos de cine. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Inicio|El administrador selecciona la opción de actualizar el catálogo|El sistema solicita los datos a la fuente externa|
|2|Obtención de datos|La fuente externa entrega tipo, título, sinopsis, géneros, año, director o creador, duración y póster de los títulos|El sistema valida y normaliza los datos recibidos|
|3|Almacenamiento|Ninguna|El sistema agrega los títulos nuevos y actualiza los existentes, sin duplicarlos (identificados por fuente, tipo e identificador externo)|
|4|Error de conexión|Ninguna|Si la fuente no responde, el sistema conserva el catálogo actual e informa del error|
|5|Resultado|Ninguna|El sistema muestra el resumen del proceso, indicando los títulos agregados y actualizados|

3. **Moderar reseñas:** Permite al administrador revisar el contenido de las reseñas y decidir si se ocultan o se restablecen. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Acceso|El administrador ingresa a la moderación de reseñas|El sistema muestra el listado de reseñas|
|2|Revisión|El administrador selecciona una reseña|El sistema muestra su contenido, autor, título y visibilidad|
|3|Ocultar|El administrador decide ocultar la reseña|El sistema la oculta, la excluye del promedio, el ranking, las etiquetas de la comunidad y las recomendaciones generales, y notifica a su autor|
|4|Restablecer|El administrador decide restablecer una reseña oculta|El sistema la vuelve visible y recalcula el promedio y las etiquetas|

4. **Cerrar  sesión:**  Permite  al  administrador  terminar  su  sesión  en  CineMatch  de  forma segura. 

 

|**Paso**|**Evento**|**Acción**|**Resultado**|
| - | - | - | - |
|1|Solicitud de cierre|El administrador selecciona la opción de cerrar sesión|El sistema finaliza la sesión|
|2|Redirección|Ninguna|El sistema redirige a la pantalla de inicio de sesión|

7. **Modelo<a name="_page27_x82.00_y70.92"></a> entidad-relación** 

El modelo entidad-relación de CineMatch representa la estructura de datos necesaria para soportar  las  funcionalidades  de  la  plataforma  y  organizar  de  manera  consistente  la información  generada  durante  su  funcionamiento.  El  modelo  integra  las  entidades relacionadas con los usuarios, sus roles, intereses y relaciones de amistad; el catálogo de películas  y  series  (contenido)  y  sus  géneros;  las  reseñas  y  sus  etiquetas;  la  biblioteca personal (seguimiento); las recomendaciones dirigidas; las notificaciones asociadas y los tokens de recuperación de contraseña. 

Las  entidades  se  relacionan  mediante  llaves  primarias  (PK)  y  llaves  foráneas  (FK), permitiendo mantener  la  integridad  y  trazabilidad  de  la información. La  relación entre contenidos y géneros se resuelve mediante la tabla intermedia contenido\_genero, la de usuarios  y  géneros  de  interés  mediante  interes\_usuario,  y  la  de  reseñas  y  etiquetas mediante resena\_etiqueta. Las tablas amistad y recomendacion permiten representar las interacciones  entre  usuarios  en  sus  diferentes  roles  dentro  de  una  misma  relación. Asimismo, resena, seguimiento y notificacion vinculan la actividad de los usuarios con los contenidos, las amistades y las recomendaciones correspondientes. 

El modelo también permite diferenciar la información propia de cada usuario de aquella que se genera como resultado de sus interacciones con otros usuarios. Las reseñas quedan asociadas al usuario que las publica y al contenido correspondiente, e incluyen la calificación (de 1 a 5), la visibilidad (pública o solo para amigos) y la marca de spoiler. Las etiquetas se normalizan en una tabla propia, lo que permite contar coincidencias entre las reseñas de un mismo título. El seguimiento conserva el estado de cada título para cada usuario: pendiente, viendo, vista o abandonada. 

Por otra parte, las recomendaciones almacenan la relación entre el usuario que las emite, el usuario que las recibe y el contenido recomendado, junto con un motivo opcional, una reseña adjunta opcional, el indicador fueraDeIntereses y las fechas de apertura, respuesta y completado. Las notificaciones referencian, de forma excluyente, una recomendación, una amistad o una reseña según su tipo. Además, el catálogo incorpora la fuente, el identificador externo y la fecha de actualización para facilitar la integración y el mantenimiento de la información obtenida desde la API externa. 

En la siguiente página se presenta el diagrama entidad-relación de CineMatch, en el que se muestran las entidades, sus campos principales y las relaciones establecidas entre ellas. El detalle de los campos, tipos de datos, descripciones y restricciones de cada tabla se presenta posteriormente en el diccionario de datos de la sección 2.9. 

![](Aspose.Words.69a4485e-d3ec-40ea-8322-cb0ba1e26bc0.005.jpeg)

***Figura 3.** Modelo entidad-relación de CineMatch*

8. **Diagrama<a name="_page29_x82.00_y70.92"></a> de secuencia**

Los diagramas de secuencia muestran la interacción, en orden cronológico, entre los actores, la interfaz web, el sistema CineMatch, la base de datos y los sistemas externos en los flujos más representativos de la plataforma. 

**Recomendar un título a un amigo (Usuario)** 

![](Aspose.Words.69a4485e-d3ec-40ea-8322-cb0ba1e26bc0.006.jpeg)

***Figura 4.** Diagrama de secuencia: Recomendar un título a un amigo (Usuario)*

**Secuencia:** 

1. El usuario selecciona un título y la opción de recomendarlo a un amigo. 
1. La interfaz solicita al sistema CineMatch la lista de amigos para ese título. 
1. El sistema consulta en la base de datos los amigos del usuario, sus intereses y quiénes ya vieron el título. 
1. El sistema ordena la lista: primero los amigos con géneros en común (por cantidad de coincidencias) y luego “otros amigos”, y marca como “ya la vio” a quienes ya lo vieron. 
1. El usuario elige al amigo, escribe un motivo opcional y, si lo desea, adjunta su reseña. Si eligió a uno de “otros amigos”, la interfaz le avisa de que no sigue esa categoría y el usuario decide continuar. 
1. La interfaz envía los datos de la recomendación al sistema CineMatch. 
1. El sistema valida que exista la amistad, que el amigo no haya visto el título, que no exista una recomendación previa del mismo título al mismo amigo y que la reseña adjunta, si hay, sea del emisor. 
1. El sistema registra la recomendación en estado “enviada”, con el indicador de fuera de intereses, y genera la notificación en la base de datos. 
1. La base de datos confirma el registro al sistema. 
1. El sistema envía al amigo una notificación en tiempo real, con el aviso de fuera de intereses si aplica, y confirma el envío a la interfaz. 
1. La interfaz informa al usuario que la recomendación fue enviada exitosamente. 

**Flujos alternativos:** 

**A1.**  Si no existe la amistad, el amigo ya vio el título o ya existe una recomendación 

previa,  el  sistema  rechaza  el  envío  y  la  interfaz  muestra  el  mensaje correspondiente. 

**A2.**  Si el motivo supera los 500 caracteres o la reseña adjunta no es válida, el sistema 

devuelve el error de validación y la interfaz solicita corregirlo. 

**A3.**  Si el amigo no está conectado, el sistema conserva la notificación y la muestra 

cuando inicie sesión. 


**Gestionar y completar una recomendación recibida (Usuario destinatario)** 

![](Aspose.Words.69a4485e-d3ec-40ea-8322-cb0ba1e26bc0.007.jpeg)

***Figura 5.** Diagrama de secuencia: Gestionar y completar una recomendación recibida (Usuario destinatario)*

**Secuencia:** 

1. El destinatario abre la recomendación recibida. 
1. La interfaz solicita el detalle de la recomendación al sistema CineMatch. 
1. El  sistema  marca  la  recomendación  como  “abierta”  (si  estaba  “enviada”)  y devuelve el motivo, el indicador de fuera de intereses y, si existe y no está oculta, la calificación y las etiquetas de la reseña adjunta. 
1. El destinatario decide: agregar el título a sus pendientes, descartarlo, o verlo y calificarlo. 
1. Si lo agrega a pendientes, el sistema lo registra como pendiente en la biblioteca, cambia la recomendación a “aceptada” y notifica al emisor. Si lo descarta, cambia a “descartada” sin notificar. 
1. Cuando el destinatario marca el título como visto, lo califica de 1 a 5 y, si lo desea, escribe su reseña con visibilidad y etiquetas, la interfaz envía los datos al sistema. 
1. El sistema valida la puntuación, el texto de la reseña (sanitizado) y las etiquetas. 
1. El sistema guarda la reseña, registra el título como visto y cambia a “completada” las  recomendaciones  de  ese  título  que  estén  en  estado  enviada,  abierta  o aceptada. 
1. El sistema genera y envía a cada emisor una notificación en tiempo real con la calificación y, si lo dejó, el comentario del destinatario. 
1. El sistema confirma el registro a la interfaz y esta muestra al destinatario la confirmación de su calificación y reseña. 

**Flujos alternativos:** 

**A1.**  Si  la  calificación  está  fuera  de  rango  o  hay  más  de  5  etiquetas,  el  sistema 

devuelve el error de validación y la interfaz solicita corregirlo. 

**A2.**  Si la reseña adjunta fue eliminada u ocultada por moderación, el sistema muestra 

solo el motivo y conserva la recomendación. 

**A3.**  Si el emisor no está conectado, el sistema conserva la notificación y la muestra 

cuando inicie sesión. 


**Actualizar el catálogo base de películas y series (Administrador)** 

![](Aspose.Words.69a4485e-d3ec-40ea-8322-cb0ba1e26bc0.008.jpeg)

***Figura 6.** Diagrama de secuencia: Actualizar el catálogo base de películas y series (Administrador)*

**Secuencia:** 

1. El  administrador  accede  a  CineMatch  y  selecciona  la  opción  de  actualizar  el catálogo. 
1. La interfaz envía la solicitud de actualización al sistema. 
1. El sistema consulta a la API externa los datos de los títulos (tipo, título, sinopsis, géneros, año, director o creador, duración y póster). 
1. La API externa devuelve los datos solicitados. 
1. El  sistema  valida  y  normaliza  los datos  y  verifica  que no  se dupliquen  títulos (fuente, tipo e identificador externo). 
1. El sistema agrega los títulos nuevos y actualiza los existentes en la base de datos. 
1. La base de datos confirma el registro al sistema. 
1. El sistema envía a la interfaz el resumen del proceso. 
1. La interfaz informa al administrador el resultado de la actualización. 

**Flujos alternativos:** 

**A1.**  Si la API externa no responde o devuelve un error, el sistema conserva el catálogo 

almacenado, registra el error e informa al administrador; el resto de la plataforma sigue operando con los datos existentes. 

**A2.**  Si algún registro recibido es inválido, el sistema lo omite e indica en el resumen 

cuántos fueron descartados. 


9. **Diccionario<a name="_page35_x82.00_y70.92"></a> de datos**

El diccionario de datos describe cada tabla de la base de datos de CineMatch, con el tipo de dato de cada campo, su descripción y sus restricciones. Cuando una tabla tiene restricciones que involucran varios campos (UNIQUE compuestos o CHECK), se indican en la última fila de la tabla, con el fin de facilitar la comprensión de la estructura y las reglas de integridad de la base de datos. 

**Tabla: rol** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idRol|INT|Identificador único del rol|Primary Key, Auto-Increment|
|nombre|VARCHAR(30)|Nombre del rol (usuario, administrador)|Not Null, Unique|

**Tabla: usuario** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idUsuario|INT|Identificador único del usuario|Primary Key, Auto-Increment|
|nombre|VARCHAR(100)|Nombre del usuario|Not Null|
|username|VARCHAR(20)|Nombre público único del usuario (3 a 20 caracteres: letras, números y guion bajo)|Not Null, Unique (sin distinguir mayúsculas), CHECK longitud ≥ 3|
|correo|VARCHAR(255)|Correo electrónico, usado para iniciar sesión|Not Null, Unique|
|contrasena|VARCHAR(255)|Contraseña del usuario almacenada como hash|Not Null|
|avatarUrl|VARCHAR(255)|URL de la imagen de perfil|Null|
|bio|VARCHAR(300)|Biografía breve del usuario|Null|
|fechaRegistro|DATETIME|Fecha y hora de creación de la cuenta|Not Null|
|Rol\_idRol|INT|Rol asignado al usuario|Foreign Key (rol.idRol), Not Null|

**Tabla: token\_recuperacion** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idToken|INT|Identificador único del token de recuperación|Primary Key, Auto-Increment|
|Usuario\_idUsuario|INT|Usuario que solicitó recuperar su contraseña|Foreign Key (usuario.idUsuario), Not Null|
|tokenHash|VARCHAR(255)|Hash del token enviado por correo|Not Null, Unique|



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|fechaExpiracion|DATETIME|Fecha y hora de vencimiento (1 hora después de su creación)|Not Null|
|usado|TINYINT(1)|Indica si el token ya fue utilizado (es de un solo uso)|Not Null, Default false|

**Tabla: genero** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idGenero|INT|Identificador único del género|Primary Key, Auto-Increment|
|nombre|VARCHAR(50)|Nombre del género|Not Null, Unique|

**Tabla: interes\_usuario** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|Usuario\_idUsuario|INT|Usuario que sigue el género (mínimo 3 al registrarse, validado por la aplicación)|Primary Key, Foreign Key (usuario.idUsuario)|
|Genero\_idGenero|INT|Género de interés del usuario|Primary Key, Foreign Key (genero.idGenero)|

**Tabla: amistad** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idAmistad|INT|Identificador único de la solicitud o relación de amistad|Primary Key, Auto-Increment|
|Usuario\_idSolicitante|INT|Usuario que envía la solicitud de amistad|Foreign Key (usuario.idUsuario), Not Null|
|Usuario\_idReceptor|INT|Usuario que recibe la solicitud de amistad|Foreign Key (usuario.idUsuario), Not Null|
|estado|ENUM|Estado de la solicitud: pendiente, aceptada o rechazada|Not Null, Default 'pendiente'|
|fechaSolicitud|DATETIME|Fecha y hora de envío de la solicitud|Not Null|
|fechaRespuesta|DATETIME|Fecha y hora en que se aceptó o rechazó la solicitud|Null|
|Restricciones de tabla|—|Evitan la autoamistad y las solicitudes duplicadas o inversas|CHECK (Usuario\_idSolicitante <> Usuario\_idReceptor); UNIQUE sobre el par no ordenado de usuarios (LEAST y GREATEST de ambos ids)|

**Tabla: contenido** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idContenido|INT|Identificador único del contenido (película o serie)|Primary Key, Auto-Increment|
|tipo|ENUM|<p>Tipo de contenido: pelicula </p><p>o serie (la serie se trata como una sola unidad)</p>|Not Null|
|titulo|VARCHAR(255)|Título del contenido|Not Null|
|sinopsis|TEXT|Sinopsis del contenido|Null|
|anio|SMALLINT|Año de estreno (o de inicio, en las series)|Null|
|director|VARCHAR(150)|Director (película) o creador (serie)|Null|
|duracion|SMALLINT|Duración en minutos (película) o duración promedio por episodio (serie)|Null|
|posterUrl|VARCHAR(255)|URL del póster del contenido|Null|
|fuente|VARCHAR(30)|Fuente o API externa de la que proviene el contenido|Not Null|
|idExterno|VARCHAR(50)|Identificador del contenido en la fuente o API externa|Not Null|
|fechaActualizacion|DATETIME|Fecha de la última actualización desde la fuente externa|Not Null|
|Restricciones de tabla|—|Un mismo identificador externo puede repetirse entre películas y series|UNIQUE (fuente, tipo, idExterno)|

**Tabla: contenido\_genero** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|Contenido\_idContenido|INT|Contenido asociado al género|Primary Key, Foreign Key (contenido.idContenido)|
|Genero\_idGenero|INT|Género asociado al contenido|Primary Key, Foreign Key (genero.idGenero)|

**Tabla: resena** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idResena|INT|Identificador único de la reseña|Primary Key, Auto-Increment|
|Usuario\_idUsuario|INT|Usuario autor de la reseña|Foreign Key (usuario.idUsuario), Not Null|
|Contenido\_idContenido|INT|Contenido reseñado|Foreign Key (contenido.idContenido), Not Null|



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|calificacion|DECIMAL(2,1)|Calificación de 1 a 5, en pasos de 0,5|Not Null, CHECK (calificacion BETWEEN 1.0 AND 5.0 y múltiplo de 0,5)|
|comentario|TEXT|Texto de la reseña escrita por el usuario (opcional)|Null|
|visibilidad|ENUM|Quién puede leer el comentario: publica o amigos|Not Null, Default 'publica'|
|esSpoiler|TINYINT(1)|Indica si el comentario contiene spoilers|Not Null, Default false|
|visible|TINYINT(1)|Indica si la reseña está visible o fue ocultada por moderación|Not Null, Default true|
|fechaCreacion|DATETIME|Fecha y hora de publicación de la reseña|Not Null|
|fechaEdicion|DATETIME|Fecha y hora de la última edición|Null|
|Restricciones de tabla|—|Un usuario tiene una sola reseña por contenido|UNIQUE (Usuario\_idUsuario, Contenido\_idContenido)|

**Tabla: etiqueta** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idEtiqueta|INT|Identificador único de la etiqueta|Primary Key, Auto-Increment|
|texto|VARCHAR(30)|Texto normalizado de la etiqueta (minúsculas, sin tildes ni espacios sobrantes)|Not Null, Unique|

**Tabla: resena\_etiqueta** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|Resena\_idResena|INT|Reseña a la que pertenece la etiqueta (máximo 5 por reseña, validado por la aplicación)|Primary Key, Foreign Key (resena.idResena), ON DELETE CASCADE|
|Etiqueta\_idEtiqueta|INT|Etiqueta asociada a la reseña|Primary Key, Foreign Key (etiqueta.idEtiqueta)|

**Tabla: seguimiento** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idSeguimiento|INT|Identificador único del registro de seguimiento|Primary Key, Auto-Increment|
|Usuario\_idUsuario|INT|Usuario dueño del seguimiento|Foreign Key (usuario.idUsuario), Not Null|
|Contenido\_idContenido|INT|Contenido marcado por el usuario|Foreign Key (contenido.idContenido), Not Null|
|estado|ENUM|Estado del contenido para el usuario: pendiente, viendo, vista o abandonada|Not Null|
|fechaActualizacion|DATETIME|Fecha y hora del último cambio de estado|Not Null|
|Restricciones de tabla|—|Un usuario tiene un solo estado por contenido|UNIQUE (Usuario\_idUsuario, Contenido\_idContenido)|

**Tabla: recomendacion** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idRecomendacion|INT|Identificador único de la recomendación|Primary Key, Auto-Increment|
|Usuario\_idEmisor|INT|Usuario que recomienda el contenido|Foreign Key (usuario.idUsuario), Not Null|
|Usuario\_idReceptor|INT|Amigo que recibe la recomendación|Foreign Key (usuario.idUsuario), Not Null|
|Contenido\_idContenido|INT|Contenido recomendado|Foreign Key (contenido.idContenido), Not Null|
|Resena\_idResena|INT|Reseña del emisor adjunta a la recomendación (opcional)|Foreign Key (resena.idResena), Null, ON DELETE SET NULL|
|motivo|VARCHAR(500)|Motivo de la recomendación escrito por el emisor (opcional)|Null|
|fueraDeIntereses|TINYINT(1)|Indica si, al momento del envío, el contenido no coincidía con los intereses del receptor|Not Null, Default false|
|estado|ENUM|Estado de la recomendación: enviada, abierta, aceptada, descartada o completada|Not Null, Default 'enviada'|
|fechaEnvio|DATETIME|Fecha y hora de envío de la recomendación|Not Null|
|fechaApertura|DATETIME|Fecha y hora en que el receptor la abrió|Null|



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|fechaRespuesta|DATETIME|Fecha y hora en que el receptor la aceptó o descartó|Null|
|fechaCompletado|DATETIME|Fecha y hora en que el receptor vio y calificó el contenido|Null|
|Restricciones de tabla|—|Una sola recomendación por emisor, receptor y contenido, y nunca a uno mismo|UNIQUE (Usuario\_idEmisor, Usuario\_idReceptor, Contenido\_idContenido); CHECK (Usuario\_idEmisor <> Usuario\_idReceptor)|

**Tabla: notificacion** 



|**Campo**|**Tipo de Datos**|**Descripción**|**Restricciones**|
| - | - | - | - |
|idNotificacion|INT|Identificador único de la notificación|Primary Key, Auto-Increment|
|Usuario\_idDestinatario|INT|Usuario que recibe la notificación|Foreign Key (usuario.idUsuario), Not Null|
|Usuario\_idOrigen|INT|Usuario que originó la notificación (Null si la origina el sistema o el administrador)|Foreign Key (usuario.idUsuario), Null|
|tipo|ENUM|Tipo: recomendacion\_recibida, recomendacion\_aceptada, recomendacion\_completada , solicitud\_amistad, amistad\_aceptada o resena\_oculta|Not Null|
|Recomendacion\_idRecom endacion|INT|Recomendación que originó la notificación (si aplica)|Foreign Key (recomendacion.idRecomend acion), Null|
|Amistad\_idAmistad|INT|Amistad que originó la notificación (si aplica)|Foreign Key (amistad.idAmistad), Null|
|Resena\_idResena|INT|Reseña que originó la notificación (si aplica)|Foreign Key (resena.idResena), Null|
|leida|TINYINT(1)|Indica si el usuario ya leyó la notificación|Not Null, Default false|
|fechaLectura|DATETIME|Fecha y hora en que el usuario leyó la notificación|Null|
|fechaCreacion|DATETIME|Fecha y hora de creación de la notificación|Not Null|
|Restricciones de tabla|—|Cada notificación referencia exactamente un origen|CHECK (exactamente una de Recomendacion\_idRecomend acion, Amistad\_idAmistad y Resena\_idResena no es Null)|

[ref1]: Aspose.Words.69a4485e-d3ec-40ea-8322-cb0ba1e26bc0.002.png
